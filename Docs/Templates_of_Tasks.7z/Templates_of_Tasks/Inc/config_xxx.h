/**
 * @brief		
 * @details		
 * @date		azenk@2017-01-09
 **/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CONFIG_XXX_H__
#define __CONFIG_XXX_H__

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define NAME_XXX     "task_xxx"

/* Exported function prototypes ----------------------------------------------*/

#endif /* __CONFIG_XXX_H__ */
