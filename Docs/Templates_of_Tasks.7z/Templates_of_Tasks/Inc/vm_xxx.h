/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __VM_XXX_H__
#define __VM_XXX_H__

/* Includes ------------------------------------------------------------------*/
#include "stdint.h"
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/
extern const luaL_Reg vm_xxx;

#endif /* __VM_XXX_H__ */
