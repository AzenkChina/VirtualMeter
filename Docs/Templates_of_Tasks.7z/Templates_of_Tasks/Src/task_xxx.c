/**
 * @brief       
 * @details     
 * @date        2017-01-09
 **/

/* Includes ------------------------------------------------------------------*/
#include "system.h"
#include "task_xxx.h"
#include "types_xxx.h"
#include "config_xxx.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/**
  * @brief  
  */
static void xxx_init(void)
{
    
}

/**
  * @brief  
  */
static void xxx_loop(void)
{
    
}

/**
  * @brief  
  */
static void xxx_exit(void)
{
    
}

/**
  * @brief  
  */
static void xxx_reset(void)
{
    
}

/**
  * @brief  
  */
static enum __task_status xxx_status(void)
{
    return(TASK_RUN);
}


/**
  * @brief  
  */
const struct __task_sched task_xmodem = 
{
    .name               = NAME_XXX,
    .init               = xxx_init,
    .loop               = xxx_loop,
    .exit               = xxx_exit,
    .reset              = xxx_reset,
    .status             = xxx_status,
    .api                = (void *)0,
};

